    <footer>
        <script src = "/js/bootstrap.bundle.min.js"></script>
        <script src = "/js/dashboard.js"></script>
        <script src = "/js/sidebars.js"></script>
        <script src = "/js/cadCliente.js"></script>
    </footer>
    </body>
</html>