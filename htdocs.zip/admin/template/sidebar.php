<div class="container-fluid">
  <div class="row">
    <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
      <div class="position-sticky pt-3 sidebar-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="/admin/index.php">
                <span data-feather="home" class="align-text-bottom"></span>
                HOME
              </a>
            </li>
            <li class="mb-1">
          <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed" data-bs-toggle="collapse" data-bs-target="#dashboard-usuario" aria-expanded="false">
            Usuarios
          </button>
          <div class="collapse" id="dashboard-usuario">
            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
              <li><a href="/admin/cadastro.php" class="link-dark d-inline-flex text-decoration-none rounded">Cadastro</a></li>
              <li><a href="/admin/listar.php" class="link-dark d-inline-flex text-decoration-none rounded">Listar</a></li>
            </ul>
          </div>
          </li>
          <li class="mb-1">
          <button class="btn btn-toggle d-inline-flex align-items-center rounded border-0 collapsed" data-bs-toggle="collapse" data-bs-target="#dashboard-cliente" aria-expanded="false">
            clientes
          </button>
          <div class="collapse" id="dashboard-cliente">
            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
              <li><a href="/admin/cadastro-cliente.php" class="link-dark d-inline-flex text-decoration-none rounded">Cadastro</a></li>
              <li><a href="/admin/listar-cliente.php" class="link-dark d-inline-flex text-decoration-none rounded">Listar</a></li>
            </ul>
          </div>
          </li>
        </ul>
      </div>
    </nav>
  </div>
</div>