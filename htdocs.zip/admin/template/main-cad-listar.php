<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Cadastrar Usuários</h1>
      </div>
     <form action="/admin/ajax/post.php" method="post">
  <div class="row g-4">
    <div class="col-md-6">
      <input id="nome" name="nome" type="text" class="form-control" placeholder="Nome">
    </div>
    <div class="col-md-5 ">
      <input id="sobrenome" name="sobrenome" type="text" class="form-control"  placeholder="Sobrenome">
    </div>
    <div class="col-md-4 ">
      <input id="telefone" name="telefone" type="text" class="form-control" placeholder="Telefone">
    </div>
    <div class="col-md-3">
      <input id="email" name="email" type="text" class="form-control"  placeholder="Email">
    </div>
    <div class="col-md-3">
      <input id="cep" name="cep" type="text" class="form-control"  placeholder="CEP">
    </div>
  </div>
  <button type="submit" class="btn btn-primary mt-2">Enviar</button>
    </form>
</br>
</br>
</br>
<table class="table table-primary table-bordered">
  <thead>
    <tr>
      <th class="table-info" scope="col">#</th>
      <th class="table-info"scope="col">Nomes</th>
      <th class="table-info"scope="col">Sobrenome</th>
      <th class="table-info"scope="col">Telefone</th>
      <th class="table-info"scope="col">E-mail</th>
      <th class="table-info"scope="col">CEP</th>
      <th class="table-info"scope="col">Opições</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Guilherme</td>
      <td>Pelassa</td>
      <td>4544444</td>
      <td>@*********************</td>
      <td>565495844844</td>
      <td><span><i class="bi bi-pencil-square"></i></span><span><i class="ms-2 bi bi-trash"></span></td>
    </tr>
    <tr>
      <th class="table-info" scope="row">2</th>
      <td class="table-info">Jacob</td>
      <td class="table-info">Thornton</td>
      <td class="table-info">99884884</td>
      <td class="table-info">@fat</td>
      <td class="table-info">8787498888</td>
      <td class="table-info"><span><i class="bi bi-pencil-square"></i></span><span><i class="ms-2 bi bi-trash"></span></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>julia</td>
      <td>Gomes</td>
      <td>@98888888</td>
      <td>@twitter</td>
      <td>54757578587</td>
      <td><span><i class="bi bi-pencil-square"></i></span><span><i class="ms-2 bi bi-trash"></span></td>
    </tr>
    <tr>
      <th class="table-info" scope="row">4</th>
      <td class="table-info">Ana</td>
      <td class="table-info">Carolina</td>
      <td class="table-info">998887878</td>
      <td class="table-info">@corolllll222</td>
      <td class="table-info">545454554445</td>
      <td class="table-info"><span><i class="bi bi-pencil-square"></i></span><span><i class="ms-2 bi bi-trash"></span></td>
    </tr>
    <tr>
      <th scope="row">5</th>
      <td>Miguel</td>
      <td>Silva</td>
      <td>94884584844</td>
      <td>@twitter.com</td>
      <td>984985448548</td>
      <td><span><i class="bi bi-pencil-square"></i></span><span><i class="ms-2 bi bi-trash"></span></td>
    </tr>
  </tbody>
</table>
</main>