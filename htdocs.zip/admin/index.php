<?php
$titulo_pagina = "Painel de adminstração";
require_once "./template/header.php";
require_once "./template/navbar.php";
require_once "./template/sidebar.php";
require_once "./template/main-home.php";
require_once "./template/footer.php";






?>
