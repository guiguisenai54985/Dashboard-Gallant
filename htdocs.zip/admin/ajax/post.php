<?php
#para receber uma informação do formulario
#ultilizamos o metodo $_POST do php
$nome = $_POST["nome"];
$sobrenome = $_POST["sobrenome"];
$email = $_POST["email"];
$telefone = $_POST["telefone"];
echo $nome;
echo "</br>";
echo "</br>";
echo $sobrenome;
echo "</br>";
echo "</br>";
echo $email;
echo "</br>";
echo "</br>";
echo $telefone;


?>