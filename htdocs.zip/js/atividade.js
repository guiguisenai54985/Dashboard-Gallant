/*1*/
for(i = 1; i<=100; i++){
    if(i%2===0 && i % 7 ===0){
        
        console.log("patatipatata");
    }
    else if(i %2 ===0){
        console.log("patati");
    }
    else if(i % 7 === 0){
        console.log("patata");
    }
    else{
        console.log(i)
    }
}
/*2 */
let ovo = parseInt(prompt("Digite a quantidade de ovos: "));

let restocaixas = 0;
let restobandeija = 0;

let caixa = ovo / 360;
restocaixas = ovo % 360;
caixa = Math.round(caixa);

let bandeija = restocaixas / 12;
let resto_band = restocaixas % 12;
bandeija = Math.round(bandeija);

if(ovo >= 360) { 
    console.log(`O total de caixas formado foi de ${caixa}`); 
     
}
if(restocaixas >= 12) { 
    console.log(`O total de bandejas formados foi de ${bandeija}`); 
}
 /* Ovos soltos */ 
 console.log(`O total restande de ovos foi de ${restobandeija}`);