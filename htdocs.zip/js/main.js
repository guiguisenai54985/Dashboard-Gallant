/*1. Operadores*/

/* Operadores aritiméticos */

/*var num_1 = 10.90;
var num_2 = '10';
var soma = num_1 + num_2;
var subtracao = num_1-num_2;

console.log(soma);
console.log(subtracao);

let num_3 = 10;
let num_4 = 10;
const soma_2 = num_1 + num_2;
console.log(soma_2);
if(soma_2 === 20){
    let texto = "nivel de escopo de variavel";
    console.log (texto);

}
let texto = "nivel fora do escorpo com let";
console.log(texto);*/
/* exibir algo*/
/*
let saldo = prompt ("digite um valor");
console.log(saldo);*/

/* Operadores relacionais */
/*let num_5 = 0;
let num_6 = '';

if(num_5 === num_6){
    console.log("os numeros são iguais");
}
else{
    console.log("os numeros não são iguais");
}*/


/* Operadores lógicos */
/*if(num_5 === 0 && num_6 ===0){
    console.log("os numeros são iguais");
}
if(num_5 === 0 || num_6 ===0){
    console.log("os numeros não são iguais");
}*/

/*********************************************************************************************** */
/*exercicio*/
/* faça um sistema que receba o valor do salario de um empregado e se o salario for */
/*menor que R$1542,00 aplique um aumento de 20% caso contrario exiba que o funcionario não tem direitoa aumento */

/*let salario = prompt ("digite o valor de seu salario");
let valealimentacao = prompt ("digite o valor do seu vale alimentação");
let salarioalimentacao = (parseFloat(salario) + parseFloat(valealimentacao));
if(salarioalimentacao < 2569.86){
    let aumento = salario * 1.15;
    console.log("o seu aumento vai ser de: " + aumento);
}
else{
    console.log("você não tem direito a aumento de salario");
}*/
/********************************************************************************************************* */
/* no javascript podemos converter string utilizando parseFloat e prompt*/
/*
let salario1 = parseFloat(prompt("digite o valor do salario"));
let tipo = typeof(salario1);
console.log(tipo);

/*função */
/*
function somar(numero_1, numero_2){
    let soma= numero_1 + numero_2;
    return soma;
}
let numero_6 = 10;
let numero_7 = 10;

let valorSoma = somar(numero_6+numero_7);
console.log(valorSoma);


function apresentar(){
    console.log("meu nome é Guilherme");
}
let apresentacao = apresentar();
console.log(apresentar);

/*data e hora */
/*
let data = Date();
console.log(data);

/*consultando valores especificos do date */
/*
let dia = new Date().getDate();
let mes = new Date().getMonth().toLocaleString();
let ano = new Date().getFullYear();
console.log(dia);
console.log(mes);
console.log(ano);

/*buscando a data com o valor local e convertendo em string */
/*
let data_string = new Date().toLocaleDateString();
console.log(data_string);

let hora_atual = new Date().toLocaleTimeString();
let hora = new Date().getHours();
let minutos = new Date().getMinutes();
let segundos = new Date().getSeconds();

console.log(hora_atual);
console.log(hora);
console.log(minutos);
console.log(segundos);

/*matemáticas */
/*
let pi = Math.PI;
console.log(pi);
pi = Math.round(pi);
console.log(pi);

let numA = Math.random() * 100;
numA = Math.random(numA);
console.log(numA);

/*string */
/*
let nome = "guilherme";
nome = nome.toUpperCase();
console.log(nome);
nome = nome.toLowerCase();
console.log(nome);
console.log(`meu nome é ${nome}`);
nome = nome.replace('guilherme','pelassa');
console.log(nome);
*/

//importando a classe para uso

// import Pessoa from "./pessoa.class.js";
// let aluno = new Pessoa("Guilherme", "848484844", "70", "16");
// console.log(aluno.nome);
// aluno.nome = "Breno";
// console.log(aluno.nome);
// console.log(aluno.andar(aluno.nome));

import Pato from "./pato.class.js";
let animal = new Pato("cleitino", "pato real", "10", "2", "branco");
console.log(animal.nome);

