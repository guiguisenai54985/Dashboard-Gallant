class Pato{
    constructor(nome,raca,peso,idade, cor ){
        this.nome = nome;
        this.raca = raca;
        this.peso = peso;
        this.idade = idade;
        this.cor = cor;
    }
    andarr (nome){
        let nomee = this.nome;
        console.log(`${nomee} está andando`);
    }
    nadar (nome){
        let nomee = this.nome;
        console.log(`${nomee} está nadando`);
    }
    voar (nome){
        let nomee = this.nome;
        console.log(`${nomee} está voando`);
    }
}
export default Pato;