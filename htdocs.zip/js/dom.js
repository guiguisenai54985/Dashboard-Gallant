/*Objeto js */
/*
window
representa a aba do navegador que contem a pagina
*/
let corpo = document.getElementById("main");
let largura = window.innerWidth;
let altura = window.innerHeight;

if(altura <= 300){
    corpo.setAttribute("style" , "background-color: blue;");
}

/*
navegator
representa o navegador de internet em uso (browser, use-agent)
navigator.geolocation.getCurrentPosition(sucess)
*/
let localizacao = navigator.geolocation.getCurrentPosition(sucesso);

function sucesso(pos) {
    let dados = pos.coords;
    let latitude = dados.latitude;
    let longitude = dados.longitude;
    console.log(latitude);
    console.log(longitude);
}

/*
document
representa o documento html carregado na aba do navegador
possibilita a manipulação da ávore DOM
(setAttribute,classList,addEventListener,createElement,appendChild,removeChild)
*/
/*
let divHome = document.getElementById("home");
let paragrafo = document.getElementById("paragrafo");
divHome.setAttribute("style" , "width: 700px; background-color: green;");
paragrafo.setAttribute("style" , "color: red; font-size: 16px;");
paragrafo.innerText = "Este é meu paragrafo modificador por JavaScript";
*/
//buscando as imformações dos elementos
let forma = document.getElementById("forma");
let btn_quadrado = document.getElementById("quadrado");
let btn_circulo = document.getElementById("circulo");
let btn_adicinarForma = document.getElementById("adicionarForma");
let btn_removerForma = document.getElementById("adicionarForma");
let divHome = document.getElementById("home");

//quando o usuario clicar no botão
//
//
//quando o usuario clicar no botão quadrado
//ira chamar o metodo quadrado
btn_quadrado.addEventListener("click" , quadrado);
function quadrado(){
    forma.classList.remove("forma");
    forma.classList.remove("circulo");
    forma.classList.add("quadrado");
}
btn_circulo.addEventListener("click" , circulo);
function circulo(){
    forma.classList.remove("forma");
    forma.classList.remove("quadrado");
    forma.classList.add("circulo");
}
btn_adicinarForma.addEventListener("click" , adicionar);
function adicionar(){
    //primeiro passa é criar o elemento (div, span, p, a etc)
    let elemento = document.createElement('span');
    //segundo passo é adicionar a classe ao elemento
    elemento.setAttribute("class" , "quadrado mt-1");
    elemento.setAttribute("onclick" , "remover(this)");
    //terceiro passo é adicionar o elemento na div
    divHome.appendChild(elemento);
}
function remover(event){
    let elemento = event;
    divHome.removeChild(elemento);
}
function limparClasse(){
    forma.removeAttribute("class");
}