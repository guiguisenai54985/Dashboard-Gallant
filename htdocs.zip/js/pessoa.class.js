class Pessoa{
    constructor(nome,rg,peso,idade){
        this.nome = nome;
        this.rg = rg;
        this.peso = peso;
        this.idade = idade;
    }

    set nomes(nome){
        this.nome = nome;
    }
    get nomes(){
        return this.nome;
    }
    andar(nome) {
        let nomee = this.nome;
        console.log(`${nomee} está andando`);
    }
}



/*exportar a classe pessoa para ser ultilizada
em outros locais/arquivos javascript */
export default Pessoa;