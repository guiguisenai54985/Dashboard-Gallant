addEventListener('load', ()=>{
    let tabelaCliente = document.getElementById('tabela-cliente').innerHTML;
    let getDados = JSON.parse(localStorage.getItem('cliente'));

    getDados.map((cliente, index) => {
        tabelaCliente += `<tr id=${index}>
            <td>${getDados[Item].nome}</td>
            <td>${getDados[Item].sobrenome}</td>
            <td>${getDados[Item].nascimento}</td>
            <td>${getDados[Item].telefone}</td>
            <td>${getDados[Item].email}</td>
            <td>${getDados[Item].rua}</td>
            <td>${getDados[Item].cidade}</td>
        </tr>`;
    })

    /*for (Item in getDados) {
        tabelaCliente += `<tr>
            <td>${getDados[Item].nome}</td>
            <td>${getDados[Item].sobrenome}</td>
            <td>${getDados[Item].nascimento}</td>
            <td>${getDados[Item].telefone}</td>
            <td>${getDados[Item].email}</td>
            <td>${getDados[Item].rua}</td>
            <td>${getDados[Item].cidade}</td>
        </tr>`;
    }
    document.getElementById('tabela-cliente').innerHTML = tabelaCliente;
    */
})
//buscando os dados do formularios
let dadosClientes = document.getElementById('cliente');

//pegando o evento do formulario
dadosClientes.addEventListener('submit', (event) =>{
    event.preventDefault();

    let dados = new FormData(dadosClientes);
   // console.log(dados);

    //converte os dados para um objeto
    dados = Object.fromEntries(dados.entries()); 

    //console.log(dados);
    postCliente(dados);

})

function postCliente(dadosCliente) {
    fetch('http://localhost/admin/ajax/cad-usuario.php',{
        method: 'POST',
        body: JSON.stringify(dadosCliente)
    })
    .then((result) =>{
        return result.json();
    }).then((result) =>{
        cadastrarCliente(result)
    }).catch((err) =>{

    });
}

function cadastrarCliente(dadosCliente) {
    //cria um array (vetor) vazio
    let setDados = new Array();
    //verifica se existe a chave no localStorage
    //se existir salva os dados em setDados
    if(localStorage.hasOwnProperty('cliente')){
        setDados = JSON.parse(localStorage.getItem('cliente'));
    }
    console.log(setDados);
    //adiciona os dados novos vindos do formulario do cliente ao array(vetor)
    setDados.push(dadosCliente);
    localStorage.setItem('cliente', JSON.stringify(setDados));
   
    let tabelaCliente = document.getElementById('tabela-cliente');
    let dados = `<tr>
        <td>${dadosCliente.nome}</td>
        <td>${dadosCliente.sobrenome}</td>
        <td>${dadosCliente.nascimento}</td>
        <td>${dadosCliente.telefone}</td>
        <td>${dadosCliente.email}</td>
        <td>${dadosCliente.rua}</td>
        <td>${dadosCliente.cidade}</td>
        </tr>`;
    tabelaCliente.innerHTML += dados;

}

let btnCEP = document.getElementById('cep')
btnCEP.addEventListener('blur', () =>{

fetch(`http://viacep.com.br/ws/${btnCEP.value}/json/`)
.then((result) => {
    console.log(result);
    return result.json();
}).then((dados) =>{
    atualizaForm(dados);
})
.catch((err) => {

});
})

function atualizaForm(dados) {
    let clienteRua = document.getElementById('rua');
    let clienteBairro = document.getElementById('bairro');
    let clienteCidade = document.getElementById('cidade');
    let clienteEstado = document.getElementById('estado');
    let clienteIbge = document.getElementById('ibge');

    clienteRua.value = dados.logradouro;
    clienteBairro.value = dados.bairro;
    clienteCidade.value = dados.localidade;
    clienteEstado.value = dados.uf;
    clienteIbge.value = dados.ibge;
}
