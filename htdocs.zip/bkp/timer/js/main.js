let audio = new Audio("/timer/audio/alarm.mp3");

// audio.play();
// audio.pause();

let nome = "Guilherme";
//salvando uma imformação no navegador  
localStorage.setItem("meu nome" , nome);
//recuperando uma informação no navegador
let dbNome = localStorage.getItem("meu nome");

//ultilizando intervalo de tempo no navegador
// setInterval(exibeNome, 1000);

// function exibeNome(){
//     console.log(dbNome);
// }


setInterval(exibeHora, 1000);
function exibeHora(){
    let pageHora = document.getElementById("hora");
    let hora = new Date();
    hora = hora.toLocaleTimeString();
    pageHora.innerText = hora;
}