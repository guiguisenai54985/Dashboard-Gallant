addEventListener("load", ()=>{
    let horaAlarme = localStorage.getItem("horaAlarme");
    let hora2 = document.getElementById("hora2");
    hora2.innerText = horaAlarme;
})

setInterval(exibeHora, 1000);
function exibeHora(){
    let pageHora = document.getElementById("hora1");
    let pageStatus = document.getElementById("status")
    let hora1 = new Date();
    hora1 = hora1.toLocaleTimeString();
    pageHora.innerText = hora1;
    let hora2 = localStorage.getItem("horaAlarme");
    console.log(hora1);
    console.log(hora2);
    if(hora1 === hora2){
        let audio = new Audio("/timer/audio/alarm.mp3")
        audio.play();
        console.log("alarme tocando");
    }
    if (hora1 < hora2) {
        pageStatus.innerText = "Inativo";
        localStorage.setItem("status", "Inativo");
      }
      else {
        pageStatus.innerText = "Ativo";
        localStorage.setItem("status", "Ativo");
      }
}

let btn_cadastrar = document.getElementById("cadastrar");
let btn_remover = document.getElementById("remover");

btn_cadastrar.addEventListener("click", cadastrar);
function cadastrar() {
    let horaDigitada = prompt("digite o horario que gostaria que o alarme tocará");
    localStorage.setItem("horaAlarme", horaDigitada);
    hora2.innerText = horaDigitada;
}
btn_remover.addEventListener("click", remover);
function remover() {
    localStorage.removeItem("horaAlarme");
}