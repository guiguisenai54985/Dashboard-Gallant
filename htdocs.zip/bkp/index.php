<?php
$titulo = "Primeira página PHP";
$idade = 16;
if($idade >=18){
    echo "posso tirar habilitação";
}
else{
    echo "não posso titar hablitação";
}
#utilizando o for
echo "<ul>";
for($i=0; $i<=10; $i++){
    echo "<li>".$i."</li>";
}
echo "</ul>";
echo"</br>";

$nomes = array("julia", "de col", "conny");
print_r ($nomes);
echo"</br>";
var_dump($nomes);
echo"</br>";
foreach($nomes as $nome){
    echo $nome;

    echo"</br>";

}
#usando um loop
$a = 0;
while($a <=10){
    echo "1";
    $a++;
}
echo"</br>";
#criando um método no php
function soma(){
    echo 2 + 2;
}

echo soma();

echo"</br>";
function somar($a, $b){
    $somar = $a + $b;
    return $somar;
}
$numero1 = 10;
$numero2 = 10;

echo somar($numero1, $numero2);

class carro{
    function andar(){
        echo "Carro andando";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="php, senai, sesi">
    <meta name= "description" content="primeira pagina php">
    <meta name="author" content="Guilherme Pelassa">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página php</title>
</head>
<body>
    <h1><?=$titulo?></h1>
    <!-- <div class="container">
        <div class="row">
            <div class="col-sm-1 col-md-3 col-lg-4 bg-black">1</div>
            <div class="col-sm-1 col-md-3 col-lg-4 bg-danger">2</div>
            <div class="col-sm-1 col-md-3 col-lg-4 bg-success">3</div>
        </div>
    </div> -->


<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>