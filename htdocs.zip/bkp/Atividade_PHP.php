<?php
#1
$nota1 = 10;
$nota2 =10;
$nota3 = 10;
$nota4 =10;

$media = ($nota1 + $nota2 + $nota3 + $nota4) / 4;

if ($media >= 7){
    echo "aluno aprovado";
}
else{
    echo "aluno reprovado";
}
echo "</br>";

#2
$altura = 1.84;
$sexo = "masculino";
echo "</br>";
if($sexo == "masculino"){
    $peso = (72.7 * $altura) - 58;
    echo $peso;
}
else{
    $peso = (62.1 * $altura) - 44.7;
    echo $peso;
}
echo "</br>";

#3
$salario = 1300;
echo "</br>";
if($salario <= 300){
    $salarioreajustado = $salario * 1.5;
    echo $salarioreajustado;
}
else{
    $salarioreajustado = $salario * 1.3;
    echo $salarioreajustado;
}
#4
echo "<ul>";
for($i=0; $i<=5; $i++){
    echo "<li>".$i."</li>";
}
echo "</ul>";
echo"</br>";
#5
$fatorial = 1;
$numero = 5;

for ($i = $numero ; $numero<= 10; $numero++){
    $fatorial*=$numero;
    echo "</br>";
    print_r ($fatorial);
}
echo "</br>";
#6
$inicio = 1;
$final = 10;
echo "</br>";
for ($i= $inicio+1; $i < $final; $i++){
echo $i;
}
echo "</br>";
#7
$valor1 = 5;
$valor2 = 12;

for ($i = 1; $i <= $valor2; $i++) {
    
}
echo "</br>";
#8


#9


#10


#11


#12



#13


?>