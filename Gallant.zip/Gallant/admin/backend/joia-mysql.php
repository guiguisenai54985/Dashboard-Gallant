<?php 
$mysql_host = "localhost";
$mysql_usuario = "root";
$mysql_database = "gallant";
$mysql_senha = "";
?>