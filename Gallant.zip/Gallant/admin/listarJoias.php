<?php
$titulo_pagina = "Listar joias";
require_once "./template/header.php";
require_once "./template/navbar.php";
require_once "./template/sidebar.php";
require_once "./template/main-cad-listar-joias.php";
require_once "./template/footer.php";
?>