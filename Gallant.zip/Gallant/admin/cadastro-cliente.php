<?php
$titulo_pagina = "Cadastro de usuario";
require_once "./template/header.php";
require_once "./template/navbar.php";
require_once "./template/sidebar.php";
require_once "./template/main-cad-cliente.php";
require_once "./template/footer.php";
?>