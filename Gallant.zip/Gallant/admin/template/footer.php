    <footer>
        <script src = "../js/bootstrap.bundle.min.js"></script>
        <script src = "../js/dashboard.js"></script>
        <script src = "../js/sidebars.js"></script>
        <script src = "../js/cadRelogio.js"></script>
        <script src = "../js/cadJoias"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.slim.min.js"></script>
        <script src = "../../../Gallant/js/apexcharts.js"></script>
        <script src = "../../../Gallant/js/scripts.js"></script>
        <script src = "../../../Gallant/js/data.js"></script>
        
    </footer>
    </body>
</html>