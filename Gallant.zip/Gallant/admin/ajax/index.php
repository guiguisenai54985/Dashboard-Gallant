<?php
echo "Acesso não permitido";
?>